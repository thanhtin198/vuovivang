// Đặt thời gian kết thúc (ví dụ: 8 giờ 39 phút 51 giây kể từ bây giờ)
const countdownTime = new Date().getTime() + (8 * 60 * 60 + 39 * 60 + 51) * 1000;

const countdownEl = document.getElementById("countdown");

function updateCountdown() {
  const now = new Date().getTime();
  const distance = countdownTime - now;

  if (distance <= 0) {
    countdownEl.innerText = "00 ngày 00:00:00";
    return;
  }

  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);

  countdownEl.innerText = `${String(days).padStart(2, '0')} ngày ${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

updateCountdown(); // gọi lần đầu
setInterval(updateCountdown, 1000); // cập nhật mỗi giây
